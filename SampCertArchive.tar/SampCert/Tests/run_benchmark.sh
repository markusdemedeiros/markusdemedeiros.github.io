#/bin/sh 
python3 /home/lean/SampCert/Tests/SampCert-py/benchmarks.py --max=50 --quantity=1 --warmup=200 --trials=1000
